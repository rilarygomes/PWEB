const fs = require('fs');
const data = fs.readFileSync('file.txt');
//a execução é bloqueada aqui até que o arquivo ser lido completamente
console.log(data.toString())